import json
import boto3
import urllib3
from boto3.dynamodb.conditions import Key
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
sns = boto3.client('sns')

# client = boto3.client('sqs')
def lambda_handler(event, context):
    # TODO implement
    
    msg_list = event['Records']
    
    processed_response = event['Records'][0]['body']
    
    response_array = processed_response.split(',')
    
    city = response_array[0]
    tag = response_array[1]
    num_people = response_array[2]
    date = response_array[3]
    time = response_array[4]
    email = response_array[5]
    
    endpoint = 'https://search-restaurants-flwvfiwuzha4xy2fpxaerfddca.us-east-1.es.amazonaws.com'
    headers = { "Content-Type": "application/json" }
    
    http = urllib3.PoolManager()

    index = "restaurants"

    header = urllib3.make_headers(basic_auth='assignment5:Assignment5!')

    url = endpoint + '/' + index + '/_search' + '?q=' + tag

    result = http.request('GET', url,headers = header)
    print(json.loads(result.data))
    print(result.status)
    
    data = json.loads(result.data)
    
    ids = []
    for i in range(3):
        try:
            id = data['hits']['hits'][i]['_source']['id']
            ids.append(id)
        except:
            break
        
    restaurant_names = []
    restaurant_locations = []
    restaurant_ratings = []
    for pid in ids:
        table = dynamodb.Table('yelp-restaurants')
        resp = table.query(KeyConditionExpression=Key('uuid').eq(pid))

        print(resp)
        restaurant_names.append(resp['Items'][0]['name'])
        restaurant_locations.append(resp['Items'][0]['address'])
        restaurant_ratings.append(resp['Items'][0]['rating'])
        
    rtn_str = "Hello! Here are my " +  tag +  " restaurant suggestions for " + num_people +" people, for today at " +  time + " : 1. " + restaurant_names[0] + ", located at " + restaurant_locations[0] + " rated at " + restaurant_ratings[0] + "stars " + ", 2. " + restaurant_names[1] + ", located at " + restaurant_locations[1]+ " rated at " + restaurant_ratings[1] + "stars " + ", 3. " + restaurant_names[2] + ", located at " + restaurant_locations[2] + " rated at " + restaurant_ratings[0] + " stars " + ". Enjoy your meal!" 
    print(rtn_str)

    
    # _SubscriptionArn = sns.subscribe(
    #     TopicArn='arn:aws:sns:us-east-1:004807650303:RestaurantSuggestion',
    #     Protocol='email',
    #     Endpoint= email,
    #     ReturnSubscriptionArn=True
    #     )
    
    response = sns.publish(
        TopicArn='arn:aws:sns:us-east-1:004807650303:RestaurantSuggestion',
        Message=rtn_str,
        Subject='Your Restaurant Suggestion!'

)
    
    # response2 = sns.unsubscribe(
    #     SubscriptionArn= _SubscriptionArn['SubscriptionArn']
    #     )
    return {
        'statusCode': 200,
        'body': json.dumps(response),
        # 'r' : r["messages"]
    }
