import json
import boto3
import urllib3
from boto3.dynamodb.conditions import Key
import datetime;
bot = boto3.client('lexv2-runtime')


def lambda_handler(event, context):

    msg = event['messages'][0]['unstructured']['text']
    bot_response = bot.recognize_text(
        botId='VYEETSZCD3',
        botAliasId='TSTALIASID',
        localeId='en_US',
        sessionId="test_session",
        text= msg)
    bm_text = bot_response['messages'][0]['content']
    
    UnstructuredMessage = {
    "id" : 1101,
    "text" : bm_text,
    "timestamp": str(datetime.datetime.now())
    }

    Message ={
    "type" : 'unstructured',
    "unstructured" : UnstructuredMessage
    }
    BotResponse = {
    "messages" : [Message]
    }
    # Message = "Hi! "
    
    return {
        'statusCode': 200,
        'messages': [Message]
        # 'bot_response' : bot_response['']
        # 'event':event
        # 'messages': [event]
    }
